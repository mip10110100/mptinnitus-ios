# MPTinnitus v5 Audio Sync Notes

This package uses the user's edited education text from Column G of `V5 Review Simple` as the source for updated audio transcripts.

## What changed

- Processed **273** app content sections.
- Found **58** rows with edited education text.
- Found **0** rows with explicit edited audio script.
- Synchronized audio so the final audio transcript is the same as the final written education text unless an explicit edited audio script exists.
- Filled the `Edited Audio Script` column for rows where Column G contained an edited written section.
- Added `Implementation Ready v5`, `Audio Queue Ready`, and `Text-to-Audio Sync Log` sheets.

## Source rule

`Final Audio Transcript = Edited Audio Script if supplied; otherwise Edited Education Text if supplied; otherwise Current Education Text.`

This matches the updated direction: the audio should act as the read-aloud transcript of the educational section, not as a detached summary.

## Files generated

- `mptinnitus_v5_app_content_master_audio_synced.xlsx`
- `mptinnitus_v5_final_content_sections.csv`
- `mptinnitus_v5_final_audio_queue.csv`

## Next step

Review the `Implementation Ready v5` and `Audio Queue Ready` sheets. After approval, these can become the source for updating the app's content and audio manifests.
